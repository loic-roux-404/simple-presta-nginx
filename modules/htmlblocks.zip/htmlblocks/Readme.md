# Multiple HTML Blocks

## About

Add blocks of custom text or html to any hook. Merges block management from ls_linklist and a bit of function from ps_customtext
